<?php
include_once("../model/reservation.php");


$c = new reservation();

$date = $_POST['date'];
$ntab = $_POST['nt'];
$cin = $_GET['cin'];

$oldntab = $_GET['oldntab'];
$olddate = $_GET['olddate'];

$c ->modifier($date,$cin,$ntab,$olddate,$oldntab);

header("Location: ../views/hello.php");

?>