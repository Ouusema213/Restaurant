<?php

$username = $_POST["username"];
$password= $_POST["password"];
$cin= $_POST["cin"];
$nom= $_POST["nom"];
$prenom = $_POST["prenom"];

include_once("../model/client.php");


$c = new client();

   
        $c->insertLog($username, $password);
        $c->insert($cin,$nom,$prenom );

        header("Location: ../views/index.php");
    
?>