<?php
include_once("../model/reservation.php");


$c = new reservation();

$date = $_GET['date'];
$ntab = $_GET['ntab'];

$c ->delete($date,$ntab);


header("Location: ../views/hello.php");

?>