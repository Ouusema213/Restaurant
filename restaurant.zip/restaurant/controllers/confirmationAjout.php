<?php


$nt = $_POST["nt"];
$cin = $_POST["cin"];
$date = $_POST["date"];

include_once("../model/reservation.php");

$c = new reservation();
$c -> insert($date,$cin,$nt);
header("Location: ../views/hello.php");




?>