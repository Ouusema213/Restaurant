<?php
include_once("../model/table.php");
include_once("../model/client.php");

$t = new table();
$c = new client();

$res = $t->liste();

$res2 = $c->liste();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserver une Table </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="bg-primary text-white text-center py-3">
    <h1>Reserver une Table</h1>
</header>

<div class="container mt-4">
    <form action="../controllers/confirmationAjout.php" method="post">
        <table class="table caption-top">
            <thead>
                <tr>
                    <th scope="col">Numero Table</th>
                    <th scope="col">Numero CIN - Nom</th>
                    <th scope="col">Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><select class="form-select" aria-label="Default select example" name="nt">
                        <?php foreach ($res as $tab):?>
                        <option value="<?php echo $tab[0];?>"><?php echo $tab[0];?></option>
                        <?php endforeach;?>
                        </select></td>
                    <td><select class="form-select" aria-label="Default select example" name="cin">
                        <?php foreach ($res2 as $tab):?>
                        <option value="<?php echo $tab[0];?>"><?php echo $tab[0];?> - <?php echo $tab[1] ?></option>
                        <?php endforeach;?>
                        </select></td></td>
                    <td><input type="text" name="date" class="form-control" id=""></td>
                </tr>
                
            </tbody>
        </table>
        <input type="submit" value="Ajouter" class="btn btn-primary">
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
