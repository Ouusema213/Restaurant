<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Login Form</title>
</head>
<style>
    body {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  margin: 0;
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
}

.login-container {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.login-form {
  display: flex;
  flex-direction: column;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

label {
  margin-bottom: 8px;
}

input {
  padding: 8px;
  margin-bottom: 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 10px;
  background-color: #4caf50;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}

</style>
<body>
  <div class="login-container">
    <form action="../controllers/confirmationReg.php" method="post" class="login-form">
      <h2>Inscription</h2>

      <label for="username">Username:</label>
      <input type="text" id="username" name="username" required>

      <label for="cin">Cin:</label>
      <input type="text" id="cin" name="cin" required>

      <label for="nom">Nom:</label>
      <input type="text" id="nom" name="nom" required>

      <label for="prenom">Prenom:</label>
      <input type="text" id="prenom" name="prenom" required>
      
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
      
      <button type="submit">Inscrir</button>
    </form>
  </div>
</body>
</html>
