<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant el BeauGoss</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <style >
    
  </style>
  

<header class="text-center py-3">
    <h1>Restaurant el BeauGoss</h1>
    <h2>Welcome ~<?php echo $_GET["user"] ?>~</h2>
</header>

<div class="container mt-4">
    <form action="" method="post">
        <table class="table caption-top">
    <thead>
      <tr>
        <th scope="col">N table</th>
        <th scope="col">Nb de personne max</th>
  
        <th scope="col" colspan="3">les jours Reserver</th>
        

      </tr>
    </thead>
    <tbody>
      <?php
      
      include_once("../model/reservation.php");
      include_once("../model/table.php");
      include_once("../model/client.php");


      $c = new reservation();
      $c2 = new table();
      $cl = new client();
      $res = $c->liste() ;
      if($res){
      while($row = $res->fetch()){
        echo "<tr><th>$row[2]</th>";
        $res2 = $c2->liste_id($row[2]);
        $item = $res2->fetch();
        
        echo ("<th>$item[1]</th>");

    
        echo "
        <th scope='row'>
          $row[0]
        </th>";
        echo"<th scope='row'>
        <div class='col-12'>
    <a href='../controllers/Supprimer.php?date=".$row[0]."&ntab=".$row[2]."'>Delete</a>
  </div> 
      </th>".
      "<th scope='row'>
        <div class='col-12'>
    <a href='update.php?date=".$row[0]."&ntab=".$row[2]."&cin=".$row[1]."'>Update</a>
  </div> 
      </th>";
        
        
    }}

?>
    
    </tbody>
    </table>

        <input type="submit" value="Ajouter Reservation" formaction="ajouterReservation.php" class="btn btn-primary">
        <input type="submit" value="Log out" formaction="index.php" class="btn btn-danger">
    </form>
</div>

<footer class="bg-light text-dark text-center py-3 mt-4" style="">
    <p>Contactez-nous: oussemanassraoui@gmail.com</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>