<?php
include_once('modele.php');
class table extends Modele {
    private $numero_table,$nombre_personne,$nombre_table;
    function __construct(){
        parent ::__construct();
    }

    function insert($numero_table,$nombre_personne,$nombre_table){
        $query="insert into tablers(numero_table,nombre_personne,nombre_table) values(? ,? ,? )";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($numero_table,$nombre_personne,$nombre_table));
    }

    function insertLog($username,$password){
        $query="insert into login(username,password) values(? ,?)";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($username,$password));
    }
    

    function liste(){
        $query = "select * from tablers";
        $res=$this->pdo->query($query);
        return $res;
    }
    function liste_id($id){
        $query = "select * from tablers where numero_table= $id ";
        $res=$this->pdo->query($query);
        return $res;
    }

    function listeLog(){
        $query = "select * from login";
        $res=$this->pdo->query($query);
        return $res;
    }
    function modifier($numero_table,$nombre_personne,$nombre_table,$numAnc)
    {
        $sql = "UPDATE tablers SET  numero_table=?, nombre_personne=?,nombre_table=? WHERE numero_table=?";
        $stmt= $this->pdo->prepare($sql);
        $stmt->execute(array($numero_table,$nombre_personne,$nombre_table,$numAnc));
    }

    function delete($numero_table) {
        $query = "delete from table where numero_table=?";
        $res=$this->pdo->prepare($query);
        return $res->execute(array($numero_table));
        }
}

?>