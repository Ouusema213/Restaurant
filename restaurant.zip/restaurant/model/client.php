<?php
include_once('modele.php');
class client extends Modele {
    private $cin,$nom,$prenom;
    function __construct(){
        parent ::__construct();
    }

    function insert($cin,$nom,$prenom){
        $query="insert into client(cin,nom,prenom) values(? ,? ,? )";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($cin,$nom,$prenom));
    }
    function insertLog($username,$password){
        $query="insert into login(username,password) values(? ,?)";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($username,$password));
    }
    function listeLog(){
        $query = "select * from login";
        $res=$this->pdo->query($query);
        return $res;
    }
   
  
    function liste(){
        $query = "select * from client";
        $res=$this->pdo->prepare($query);
        $res->execute();
        return $res;
    }

   
    function modifier($cin,$nom,$prenom,$numAnc)
    {
        $sql = "UPDATE client SET  cin=?, nom=?,prenom=? WHERE cin=?";
        $stmt= $this->pdo->prepare($sql);
        $stmt->execute(array($cin,$nom,$prenom,$numAnc));
    }

    function delete($cin) {
        $query = "delete from table where cin=?";
        $res=$this->pdo->prepare($query);
        return $res->execute(array($cin));
        }
}

?>