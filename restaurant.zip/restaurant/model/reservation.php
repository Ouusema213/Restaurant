<?php
include_once('modele.php');
class reservation extends Modele {
    private $dateres,$cin,$numero_table;
    function __construct(){
        parent ::__construct();
    }

    function insert($dateres,$cin,$numero_table){
        $query="insert into reservation(dateres,cin,numero_table) values(? ,? ,? )";
        $res = $this->pdo->prepare($query);
        return $res->execute(array($dateres,$cin,$numero_table));
    }

   
    

    function liste(){
        $query = "select * from reservation";
        $res=$this->pdo->query($query);
        return $res;
    }

   
    function modifier($dateres,$cin,$numero_table,$olddate,$oldnum)
    {
        $sql = "UPDATE reservation SET  dateres=?, cin=?,numero_table=? WHERE dateres=? and numero_table=?";
        $stmt= $this->pdo->prepare($sql);
        $stmt->execute(array($dateres,$cin,$numero_table,$olddate,$oldnum));
    }

    function delete($dateres,$ntab) {
    
        $query = "DELETE from reservation WHERE dateres=? and numero_table=?";
    
        $res=$this->pdo->prepare($query);
        return $res->execute(array($dateres,$ntab));
        }
}

?>